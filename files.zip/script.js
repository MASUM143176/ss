// Lightweight app: loads teams.json, search/filter, team + player galleries, lightbox
let teams = [];
let lbState = { images: [], idx: 0 };

async function loadTeams(){
  const res = await fetch('teams.json');
  teams = await res.json();
  populateRegionFilter();
  renderTeams(teams);
}

function populateRegionFilter(){
  const sel = document.getElementById('regionFilter');
  const regions = Array.from(new Set(teams.map(t => t.region).filter(Boolean)));
  regions.forEach(r => {
    const opt = document.createElement('option');
    opt.value = r; opt.textContent = r;
    sel.appendChild(opt);
  });
  sel.addEventListener('change', applyFilters);
  document.getElementById('search').addEventListener('input', applyFilters);
}

function applyFilters(){
  const q = document.getElementById('search').value.toLowerCase();
  const region = document.getElementById('regionFilter').value;
  const filtered = teams.filter(t => {
    const teamText = (t.name + ' ' + (t.country||'') + ' ' + (t.players||[]).map(p => p.in_game_name + ' ' + p.name).join(' ')).toLowerCase();
    if (region && t.region !== region) return false;
    if (q && !teamText.includes(q)) return false;
    return true;
  });
  renderTeams(filtered);
}

function renderTeams(list){
  const container = document.getElementById('teams-list');
  container.innerHTML = '';
  list.forEach(team => {
    const card = document.createElement('article');
    card.className = 'card';
    card.innerHTML = `
      <div class="card-row">
        <img class="team-logo" src="${team.logo||'https://via.placeholder.com/64'}" alt="${team.name} logo">
        <div>
          <div style="font-weight:700">${team.name}</div>
          <div class="team-meta">${team.country || ''} · ${team.region || ''}</div>
        </div>
      </div>
      <div style="margin-top:.6rem" class="small">Players: ${team.players.length}</div>
      <div class="gallery" style="margin-top:.6rem">
        ${ (team.photos||[]).slice(0,3).map(p => `<img loading="lazy" class="thumb" src="${p.url}" data-team="${team.id}" data-photo-index="${team.photos.indexOf(p)}" alt="${p.caption||team.name}">`).join('') }
      </div>
    `;
    card.addEventListener('click', (e)=> {
      // avoid opening team if a thumb clicked -- that should open lightbox
      if (e.target.classList.contains('thumb')) return;
      showTeam(team);
    });
    container.appendChild(card);
  });

  // attach click on thumbs in the list (open team photo)
  container.querySelectorAll('.thumb').forEach(img => {
    img.addEventListener('click', (ev) => {
      ev.stopPropagation();
      const teamId = img.dataset.team;
      const idx = Number(img.dataset.photoIndex);
      const team = teams.find(t => t.id === teamId);
      if (team) openLightbox(team.photos.map(p => ({url:p.url, caption:p.caption||team.name})), idx);
    });
  });
}

function showTeam(team){
  const panel = document.getElementById('detail-panel');
  const out = document.getElementById('team-detail');
  panel.classList.remove('hidden');
  panel.setAttribute('aria-hidden', 'false');

  out.innerHTML = `
    <h2>${team.name}</h2>
    <div class="small">${team.country || ''} · ${team.region || ''}</div>
    <p class="section-title">Team Gallery</p>
    <div class="gallery">${(team.photos||[]).map((p,i)=>`<img loading="lazy" class="thumb" src="${p.url}" data-gallery="${team.id}" data-index="${i}" alt="${p.caption||team.name}">`).join('') || '<div class="small">No photos</div>'}</div>
    <img class="gallery-large" src="${team.photos && team.photos[0] ? team.photos[0].url : (team.logo||'https://via.placeholder.com/800x300')}" alt="${team.name}">

    <p class="section-title">Roster</p>
    ${team.players.map(p => playerHtml(p)).join('')}

    <p class="section-title">Achievements</p>
    <div class="small">${(team.achievements || []).join('; ') || 'No achievements recorded.'}</div>

    <p class="section-title">Sponsors & Gear</p>
    <div class="small">${(team.sponsors || []).join(', ') || '—'}</div>

    <p class="section-title">Team Notes</p>
    <div class="small">${team.notes || 'No notes'}</div>
  `;

  // attach gallery handlers inside detail panel
  out.querySelectorAll('.thumb').forEach(img => {
    img.addEventListener('click', (ev) => {
      const idx = Number(img.dataset.index);
      openLightbox((team.photos || []).map(p => ({url:p.url, caption:p.caption||team.name})), idx);
    });
  });

  // attach player gallery thumbs
  out.querySelectorAll('.player-thumb').forEach(img => {
    img.addEventListener('click', ev => {
      const data = JSON.parse(img.dataset.playerGallery);
      openLightbox(data.images, Number(img.dataset-playerIndex || 0));
    });
  });

  window.scrollTo({top:0,behavior:'smooth'});
}

function playerHtml(p){
  const socialHtml = Object.entries(p.social || {}).map(([k,v]) => `<a href="${v}" target="_blank" rel="noopener" style="color:var(--accent)">${k}</a>`).join(' · ');
  const gallery = (p.gallery || []).map(g => ({url:g.url, caption:g.caption||p.in_game_name}));
  const galleryThumbs = (p.gallery || []).slice(0,3).map(g => `<img loading="lazy" class="thumb" src="${g.url}" data-player="${p.in_game_name}" data-player-index="${(p.gallery || []).indexOf(g)}" alt="${g.caption||p.in_game_name}">`).join('');
  return `
    <div class="player">
      <img class="avatar" src="${p.avatar||'https://via.placeholder.com/80'}" alt="${p.in_game_name}">
      <div class="player-meta">
        <div style="display:flex;justify-content:space-between;align-items:center">
          <div>
            <div style="font-weight:700">${p.in_game_name} <span style="color:var(--muted)">(${p.name || '—'})</span></div>
            <div class="small">${p.role || ''} · ${p.country || ''} · Age: ${p.age || '—'}</div>
          </div>
          <div class="player-role">${p.status || ''}</div>
        </div>

        <div style="margin-top:.5rem" class="small">${p.bio_long || p.bio || 'No bio available.'}</div>

        <div class="section-title">Lifestyle & Training</div>
        <div class="small">
          Training: ${p.lifestyle?.training_hours || '—'} hrs/day · Diet: ${p.lifestyle?.diet || '—'}<br>
          Schedule: ${p.lifestyle?.schedule || '—'} · Hobbies: ${p.lifestyle?.hobbies?.join(', ') || '—'}
        </div>

        <div class="section-title">Gear & Stats</div>
        <div class="small">Mouse: ${p.gear?.mouse || '—'} · Headset: ${p.gear?.headset || '—'} · K/D: ${p.stats?.kd || '—'}</div>

        <div class="section-title">Player Gallery</div>
        <div class="gallery">
          ${galleryThumbs || '<div class="small">No photos</div>'}
        </div>

        <div class="section-title">Social</div>
        <div class="small">${socialHtml || '—'}</div>
      </div>
    </div>
  `;
}

/* Lightbox functions */
function openLightbox(images, idx = 0){
  if (!images || images.length === 0) return;
  lbState.images = images;
  lbState.idx = idx;
  const lb = document.getElementById('lightbox');
  const img = document.getElementById('lb-img');
  const caption = document.getElementById('lb-caption');
  img.src = images[idx].url;
  img.alt = images[idx].caption || '';
  caption.textContent = images[idx].caption || '';
  lb.classList.remove('hidden');
  document.body.style.overflow = 'hidden';
  updateNav();
}

function updateNav(){
  document.getElementById('lb-prev').style.display = lbState.idx > 0 ? 'block' : 'none';
  document.getElementById('lb-next').style.display = lbState.idx < lbState.images.length - 1 ? 'block' : 'none';
}

function closeLightbox(){
  const lb = document.getElementById('lightbox');
  lb.classList.add('hidden');
  document.body.style.overflow = '';
  lbState.images = []; lbState.idx = 0;
}

document.getElementById('lb-close').addEventListener('click', closeLightbox);
document.getElementById('lb-prev').addEventListener('click', () => {
  if (lbState.idx > 0) {
    lbState.idx -= 1;
    const img = document.getElementById('lb-img');
    img.src = lbState.images[lbState.idx].url;
    document.getElementById('lb-caption').textContent = lbState.images[lbState.idx].caption || '';
    updateNav();
  }
});
document.getElementById('lb-next').addEventListener('click', () => {
  if (lbState.idx < lbState.images.length - 1) {
    lbState.idx += 1;
    const img = document.getElementById('lb-img');
    img.src = lbState.images[lbState.idx].url;
    document.getElementById('lb-caption').textContent = lbState.images[lbState.idx].caption || '';
    updateNav();
  }
});
document.addEventListener('keydown', (e) => {
  if (document.getElementById('lightbox').classList.contains('hidden')) return;
  if (e.key === 'ArrowLeft') document.getElementById('lb-prev').click();
  if (e.key === 'ArrowRight') document.getElementById('lb-next').click();
  if (e.key === 'Escape') closeLightbox();
});

/* init */
document.getElementById('close-detail').addEventListener('click', ()=>{
  document.getElementById('detail-panel').classList.add('hidden');
  document.getElementById('detail-panel').setAttribute('aria-hidden','true');
});
loadTeams();