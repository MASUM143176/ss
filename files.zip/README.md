# Free Fire Teams — Demo (Gallery + Profiles)

This demo extends the previous simple site with:
- Team photo galleries and player galleries (click thumbnails to open the lightbox).
- More profile fields: long bio, achievements, sponsors, gear, stats, schedule, and more.
- Search and region filter.
- Placeholder images you can replace with real photos.

How to use
1. Put these files into a folder and open `index.html` in a browser.
2. Edit `teams.json` to add real teams, players, and photo URLs.
   - For images you can use:
     - External URLs (e.g., CDN or hosted images).
     - Local files in an `images/` folder: use `"photos": [{"url":"images/team1-1.jpg","caption":"Team photo"}]`.
3. Replace placeholder images (via.placeholder or unsplash links) with your own images.
4. To deploy, host the folder on GitHub Pages, Netlify, or any static hosting.

Data structure notes (teams.json)
- team.photos: array of { url, caption }
- team.players: each player may have:
  - avatar
  - gallery: array of { url, caption }
  - bio_long, lifestyle (training_hours, diet, schedule, hobbies), gear, stats, social

Privacy & content
- Only publish photos and personal/lifestyle info you have permission to publish.
- Avoid non-public personal data (phone, home address, private docs).
- If you plan to collect additional information from players, obtain written consent.

Next steps (ideas you can ask me to implement)
- Admin import: Google Sheet → JSON or small admin UI to add teams.
- Backend: Firebase/Airtable to edit teams online.
- Authentication + content approval workflows for player-submitted photos.
- Pagination, sorting, and analytics.

If you want, I can:
- Convert this into a deployable Git repo with CI & instructions for GitHub Pages.
- Add an import script to transform a CSV/Google Sheet into the JSON shape.
- Implement an admin editor (Netlify Identity + Netlify CMS, or a minimal Firebase editor).

Tell me which of those you'd like next and whether you have the real photos (links or a ZIP) so I can help integrate them.